-- phpMyAdmin SQL Dump
-- version 4.7.9
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Apr 03, 2018 at 12:33 PM
-- Server version: 10.1.31-MariaDB
-- PHP Version: 7.2.3

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `mobilestore`
--

-- --------------------------------------------------------

--
-- Table structure for table `admin`
--

CREATE TABLE `admin` (
  `id` int(100) NOT NULL,
  `admin` varchar(100) NOT NULL,
  `password` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `admin`
--

INSERT INTO `admin` (`id`, `admin`, `password`) VALUES
(1, 'mnnit.tej@gmail.com', 'admin');

-- --------------------------------------------------------

--
-- Table structure for table `brands`
--

CREATE TABLE `brands` (
  `brand_id` int(100) NOT NULL,
  `brand_title` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `brands`
--

INSERT INTO `brands` (`brand_id`, `brand_title`) VALUES
(1, 'honor'),
(2, 'Samsung'),
(3, 'Apple'),
(4, 'Sony'),
(5, 'Lenovo'),
(6, 'Mi(Redmi)'),
(7, 'Infinix'),
(8, 'Motorola'),
(9, 'Vivo'),
(10, 'Oppo');

-- --------------------------------------------------------

--
-- Table structure for table `cart`
--

CREATE TABLE `cart` (
  `id` int(10) NOT NULL,
  `p_id` int(10) NOT NULL,
  `ip_add` varchar(250) NOT NULL,
  `user_id` int(10) DEFAULT NULL,
  `qty` int(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `cart`
--

INSERT INTO `cart` (`id`, `p_id`, `ip_add`, `user_id`, `qty`) VALUES
(3, 1, '::1', 3, 1),
(4, 6, '::1', 4, 1),
(5, 3, '::1', 4, 1);

-- --------------------------------------------------------

--
-- Table structure for table `categories`
--

CREATE TABLE `categories` (
  `cat_id` int(100) NOT NULL,
  `cat_title` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `categories`
--

INSERT INTO `categories` (`cat_id`, `cat_title`) VALUES
(1, 'Mobile Phones'),
(2, 'Tablets'),
(3, 'Upcoming deals');

-- --------------------------------------------------------

--
-- Table structure for table `orders`
--

CREATE TABLE `orders` (
  `order_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `product_id` int(11) NOT NULL,
  `qty` int(11) NOT NULL,
  `trx_id` varchar(255) NOT NULL,
  `p_status` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `orders`
--

INSERT INTO `orders` (`order_id`, `user_id`, `product_id`, `qty`, `trx_id`, `p_status`) VALUES
(1, 2, 7, 1, '07M47684BS5725041', 'Completed'),
(2, 2, 2, 1, '07M47684BS5725041', 'Completed');

-- --------------------------------------------------------

--
-- Table structure for table `products`
--

CREATE TABLE `products` (
  `product_id` int(100) NOT NULL,
  `product_cat` int(100) NOT NULL,
  `product_brand` int(100) NOT NULL,
  `product_title` varchar(255) NOT NULL,
  `product_price` int(100) NOT NULL,
  `product_desc` text NOT NULL,
  `product_images` text NOT NULL,
  `product_keywords` text NOT NULL,
  `product_quantity` int(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `products`
--

INSERT INTO `products` (`product_id`, `product_cat`, `product_brand`, `product_title`, `product_price`, `product_desc`, `product_images`, `product_keywords`, `product_quantity`) VALUES
(1, 1, 2, 'Samsung Dous 2', 5000, 'Samsung Dous 2 sgh ', 'samsung mobile.jpg', 'samsung mobile electronics', 0),
(2, 1, 3, 'iPhone 5s', 25000, 'iphone 5s', 'iphone mobile.jpg', 'mobile iphone apple', 0),
(3, 1, 3, 'iPad', 30000, 'ipad apple brand', 'ipad.jpg', 'apple ipad tablet', 0),
(4, 1, 3, 'iPhone 6s', 32000, 'Apple iPhone ', 'iphone.jpg', 'iphone apple mobile', 0),
(5, 1, 2, 'iPad 2', 10000, 'samsung ipad', 'ipad 2.jpg', 'ipad tablet samsung', 0),
(6, 2, 3, 'ipad', 50, 'color white(128GB) ', 'ipadtab.jpg', 'ipad apple', 0),
(7, 0, 3, 'Apple i7 pluse', 100, 'color silver', 'i7+.jpg\r\n', 'iphone 7', 0),
(8, 1, 4, 'Sony', 40000, 'Sony Mobile', 'sony mobile.jpg', 'sony mobile', 0),
(9, 1, 3, 'iPhone New', 12000, 'iphone', 'white iphone.png', 'iphone apple mobile', 0),
(10, 0, 3, 'Apple i7 pluse', 100, 'color silver', 'i7+.jpg\r\n', 'iphone 7', 0),
(11, 3, 0, 'upcoming honor', 0, 'Honor 9 Lite (Midnight Black, 32 GB)  (3 GB RAM)#OnlyOn MobileStore', 'h9.jpeg', 'honor', 0),
(13, 1, 1, 'Honor Holly 2 Plus', 100, '(Gold, 16 GB)  (2 GB RAM)', 'h2+.jpeg', 'honor', 0),
(14, 1, 1, 'Honor 8 Lite (Blue, 64 GB)', 13999, 'Honor 8 Lite (Blue, 64 GB)  (4 GB RAM)', 'h8lite.jpeg', '', 0),
(15, 1, 5, 'Lenovo K6 Power', 8645, 'Lenovo K6 Power (Gold, 32 GB)  (3 GB RAM)', 'lk6.jpeg', 'Lenovo K6 Power', 0),
(16, 1, 5, 'Lenovo Phab 2', 8999, 'Lenovo Phab 2 (Champagne Gold, 32 GB)  (3 GB RAM)', 'l2.jpeg', 'Lenovo Phab 2', 0),
(17, 1, 5, 'Lenovo K8 Plus ', 9999, 'Lenovo K8 Plus (Venom Black, 32 GB)  (3 GB RAM)', 'lk8+.jpeg', '(Venom Black, 32 GB)  (3 GB RAM)', 0),
(18, 1, 6, 'Mi Max 2', 15999, 'Mi Max 2 (Black, 64 GB)  (4 GB RAM)', 'mimi2.jpeg', 'Mi Max 2', 0),
(19, 1, 6, 'mi 5A', 5999, '2GB RAM, 16GB storage variant', 'mi5a.jpeg', 'Mi 5a', 0),
(20, 1, 8, 'Moto X4', 24998, 'Moto X4 (Sterling Blue, 64 GB)  (6 GB RAM)', 'mx4.jpeg', 'Moto X4', 0),
(21, 1, 8, 'Moto Z2 Force', 34998, 'Moto Z2 Force (Super Black, 64 GB)  (6 GB RAM)', 'mz2f.jpeg', '', 0),
(22, 1, 9, 'VIVO V5', 17980, 'VIVO V5 (Crown gold, 32 GB)  (4 GB RAM)', 'v5.jpeg', 'VIVO V5 (Crown gold, 32 GB)  (4 GB RAM)', 0),
(23, 1, 9, 'VIVO V5s Perfect Selfie', 15990, 'VIVO V5s Perfect Selfie (Matte Black, 64 GB)  (4 GB RAM)', 'v5s.jpeg', 'VIVO V5s ', 0),
(24, 1, 10, 'OPPO F3', 16990, 'OPPO F3 (Gold, 64 GB)  (4 GB RAM)', 'of3.jpeg', 'OPPO F3 (Gold, 64 GB)  (4 GB RAM)', 0),
(25, 1, 10, 'OPPO A83', 12490, 'OPPO A83 (Champagne, 32 GB)  (3 GB RAM)', 'o8.jpeg', 'OPPO A83', 0),
(26, 3, 0, 'Upcoming OPPO A57', 0, 'OPPO A57 (Gold, 32 GB)  (3 GB RAM)', 'oa5.jpeg', 'OPPO A57', 0),
(27, 1, 7, 'Infinix Hot S3', 10999, 'Infinix Hot S3 (Sandstone Black, 64 GB)  (4 GB RAM)', 'ihs3.jpeg', 'Infinix Hot S3', 0),
(28, 1, 7, 'Infinix Zero 5 Pro', 19999, 'Infinix Zero 5 Pro (Bronze Gold Black, 128 GB)  (6 GB RAM)', 'in5.jpeg', 'Infinix Zero 5 Pro', 0),
(29, 1, 3, 'Apple i8plus', 65, 'apple space gray,64GB', 'i8+.jpg', 'ipad 8plus', 0),
(45, 1, 2, 'Samsung Galaxy Note 3', 10000, '0', 'samsung_galaxy_note3_note3neo.JPG', 'samsung galaxy Note 3 neo', 0),
(46, 1, 2, 'Samsung Galaxy Note 3', 10000, '', 'samsung_galaxy_note3_note3neo.JPG', 'samsung galxaxy note 3 neo', 0),
(47, 0, 0, '', 0, '', '', 'honor8', 0),
(49, 0, 0, '', 0, '', '', 'honor8', 0),
(51, 0, 0, '', 0, '', '', 'Moto Z2 Force', 0),
(53, 0, 0, '', 0, '', '', 'Moto Z2 Force', 0),
(55, 0, 0, 'this is testing', 50, '', 'product_images/8ab8ba556a0301057fa58ebb94d38244', 'this is nice product', 5),
(56, 0, 0, 'this is testing', 50, 'hhhhh', 'product_images/0528e50f319c6ad37183c2bf3ed313e7vlcsnap-2016-01-07-19h52m51s098.png', 'this is nice product', 5),
(57, 0, 0, 'this is testing', 50, 'hhhhh', 'product_images/25119e75329775dfcf3e41919705cee4vlcsnap-2016-01-07-19h52m51s098.png', 'this is nice product', 5),
(58, 0, 0, 'this is testing', 50, 'hhhhh', 'product_images/4fbb4405b0467a5be91ad93bad328872vlcsnap-2016-01-07-19h52m51s098.png', 'this is nice product', 5),
(59, 0, 0, 'this is testing', 50, 'hhhhh', 'product_images/3ae0a2afb5f83b233032636555c85136vlcsnap-2016-01-07-19h52m51s098.png', 'this is nice product', 5),
(60, 0, 0, 'this is testing', 50, 'hhhhh', 'product_images/1847e3c6584338eab9e72c5b75194892vlcsnap-2016-01-07-19h52m51s098.png', 'this is nice product', 5),
(61, 0, 0, 'this is testing', 50, 'hhhhh', 'product_images/e48eddf91cea7b256e7aebe5235f4f61vlcsnap-2016-01-07-19h52m51s098.png', 'this is nice product', 5),
(62, 0, 0, 'this is testing', 50, 'hhhhh', 'product_images/fac3d39da4dd57d2725f66ef3d6b64a4vlcsnap-2016-01-07-19h52m51s098.png', 'this is nice product', 5),
(63, 0, 0, 'this is testing', 50, 'hhhhh', 'product_images/f5d9e43a9e191ae0c22a4feb91653630vlcsnap-2016-01-07-19h52m51s098.png', 'this is nice product', 5),
(64, 0, 0, 'this is testing', 50, 'hhhhh', 'mobilestore/product_images/5518162d50e030624066c05a4b36b8cdvlcsnap-2016-01-07-19h52m51s098.png', 'this is nice product', 5),
(65, 0, 0, 'this is testing', 50, 'check', 'mobilestore/product_images/9e6912e08c43c3248fa84ea465aa1a3dvlcsnap-2016-01-31-00h16m56s679.png', 'check', 5),
(66, 0, 0, 'this is testing', 50, 'check', 'mobilestore/product_images/0852195a6151c65c8337a20161f96b82vlcsnap-2016-01-31-00h16m56s679.png', 'check', 5),
(67, 0, 0, 'this is testing', 50, 'ak', 'product_images/5d73143b50189d7ceacfb43c345d2cf0apj abdul kalam motivational quotes 1_7.jpg', 'this is nice product', 5),
(68, 0, 0, 'this is testing', 50, 'asfdjmkhgfd', 'product_images/b0464ba83a856b0ece6ce4d9ef50870915356534_1211673492253217_7022053343399271969_n.jpg', 'this is nice product', 5),
(69, 0, 0, 'this is testing', 50, 'hhhhhhhhhhhhhhhh', 'product_images/fb5ab60c5383937206ede3174999234915356534_1211673492253217_7022053343399271969_n.jpg', 'this is nice product', 5),
(70, 0, 0, 'this is testing', 50, 'hhhhhhhhhhhhhhhh', 'product_images/e4e2fbfc2c970c60c808a09b977d0dba15356534_1211673492253217_7022053343399271969_n.jpg', 'this is nice product', 5),
(71, 0, 0, 'this is testing', 50, 'jhgfdydgd', 'product_image/1c77fdbc05aad315b54dbd6f73c57856vlcsnap-2016-01-07-19h52m51s098.png', 'ha be', 5),
(72, 0, 0, 'this is testing', 50, 'jhgfdydgd', './product_image/00e453425e254c7b4cc192f92ff6ca5avlcsnap-2016-01-07-19h52m51s098.png', 'ha be', 5),
(73, 0, 0, 'this is testing', 50, 'kujgi,khn', './product_image/120dd392944413f5a242cfd3de056d5fvlcsnap-2016-01-07-19h52m51s098.png', 'hhha beeeee', 5),
(74, 0, 0, 'this is testing', 50, 'jhfdjynf', './product_image/8213f74c5cc4088f3ebfbef22c59f1d7download.jpg', 'this is nice product', 5),
(75, 0, 0, 'this is testing', 50, 'jhfdjynf', 'product_image/21db2414999e3e940413583b7b9a52dbdownload.jpg', 'this is nice product', 5),
(76, 0, 0, 'this is testing', 50, 'kiuEGFUKQWKJD', 'product_image/7c3231e1df803ffe518108c103303ab2download.jpg', 'this is nice product', 5),
(77, 0, 0, 'this is testing', 50, 'kiuEGFUKQWKJD', 'product_image/21a9e63972577a05948f904927c459bcdownload.jpg', 'this is nice product', 5),
(78, 0, 0, 'this is testing', 50, 'qawddgfhjjjjgfds', 'product_image/6dc2125c651eddf86990454e66af8d6bdownload.jpg', 'this is nice product', 5),
(79, 0, 0, 'this is testing', 50, 'qawddgfhjjjjgfds', '/product_image/7956d63b627d29ba2b17d973a2d0212adownload.jpg', 'this is nice product', 5),
(80, 0, 0, 'this is testing', 50, '', '/product_image/8d4d34da413fa46ea2edf7596fff1efbdownload.jpg', 'ghdy', 5),
(81, 0, 0, 'this is testing', 50, '', '/product_image/4a26fbe0f4e282c69c47ef5a258ae19bdownload.jpg', 'ghdy', 5),
(82, 0, 0, 'this is testing', 50, 'KASHI', '/product_image/b3f313d8493c597a0b0dc30009c6975edownload.jpg', 'kajsfdhiwEK', 5),
(83, 0, 0, 'this is testing', 50, 'KASHI', 'product_image/4773bc59a61b7c1e96bd1cab3784dd34download.jpg', 'kajsfdhiwEK', 5),
(84, 0, 0, 'this is testing', 50, 'VISHVNATH', 'product_image/77ece0122e5830c356b995ec2ac693bbdownload.jpg', 'KASHI', 5),
(85, 0, 0, 'this is testing', 50, 'vishva', 'product_images/d0c8321ac4bb5853168f15bf01a400c5download.jpg', 'kashi', 5),
(86, 0, 0, 'this is testing', 50, 'vishva', 'product_images/66d1ec2504b1b3aed5a3ec6b8b841554download.jpg', 'kashi', 5),
(87, 0, 0, 'this is testing', 50, 'dgfy', 'product_images/a43a641dfe6b3e7b917bf1dc02436328download.jpg', 'dsw', 5),
(88, 0, 0, 'this is testing', 50, 'rushikesh', 'product_images/434417aa22c06c202b21a08a3d90c5bedownload.jpg', 'rushikesh', 5),
(89, 0, 0, 'this is testing', 50, 'rushikesh', 'product_images/4f3dacd82941cbf092b865a02eb6ae1edownload.jpg', 'rushikesh', 5),
(90, 0, 0, 'this is testing', 50, 'vishva', 'product_images/764d1422db677891b59f46e5f32c17f0download.jpg', 'kashi', 5),
(91, 0, 0, '$_POST[ptit]', 0, '$_POST[pdesc]', '$dst1', '$_POST[pkey]', 0),
(92, 0, 1, 'nokia', 50, 'jjjjj', 'product_images/04b86d004d16c4f039b1e75e6a2b74bbdownload.jpg', 'this is nice product', 5),
(93, 0, 1, 'nokia', 50, 'jjjjj', '30d7fe22d1300156f4d5910c38bac4bbdownload.jpg', 'this is nice product', 5),
(94, 0, 1, 'kkkk', 50, 'apj', 'a952974ca559af8ee9cc8325eb02222dA.P.J.-Abdul-Kalam-Anmol-Vachan-Quotes-in-Hindi.jpg', 'this is nice product', 5),
(95, 0, 3, 'this is testing', 30, 'nice product', 'product_images/e0d732db9fc5b6537429d447c7048cb8nokiaa.jpg', 'Apple', 5),
(96, 0, 2, 'mob', 50, 'best product', 'product_images/729ba513f513265207a62a3c70d701bcdownload (1).jpg', 'this is nice product', 5),
(97, 0, 1, 'lava', 100, 'best in mobile', '867babbfec485acccc7d8e2b5a6a50e3download (1).jpg', 'this is nice product', 1),
(98, 0, 3, 'phnoes', 100, 'nice product', 'a470179ae586db34bf257ca6f09f058cteja.jpg', 'this is nice product', 1);

-- --------------------------------------------------------

--
-- Table structure for table `user_info`
--

CREATE TABLE `user_info` (
  `user_id` int(10) NOT NULL,
  `first_name` varchar(100) NOT NULL,
  `last_name` varchar(100) NOT NULL,
  `email` varchar(300) NOT NULL,
  `password` varchar(300) NOT NULL,
  `mobile` varchar(10) NOT NULL,
  `address1` varchar(300) NOT NULL,
  `address2` varchar(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `user_info`
--

INSERT INTO `user_info` (`user_id`, `first_name`, `last_name`, `email`, `password`, `mobile`, `address1`, `address2`) VALUES
(3, 'Vinit', 'Kumar', 'mnnitvinitkumar@gmail.com', '1234', '9876543210', 'mnnit', 'allahabad'),
(4, 'dolly', 'kumawat', 'dollykumawat.mnnit@gmail.com', '726495d37703a3988901715fffbf2325', '9644748009', 'ratlam', 'ratlam');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `admin`
--
ALTER TABLE `admin`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `brands`
--
ALTER TABLE `brands`
  ADD PRIMARY KEY (`brand_id`);

--
-- Indexes for table `cart`
--
ALTER TABLE `cart`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `categories`
--
ALTER TABLE `categories`
  ADD PRIMARY KEY (`cat_id`);

--
-- Indexes for table `orders`
--
ALTER TABLE `orders`
  ADD PRIMARY KEY (`order_id`);

--
-- Indexes for table `products`
--
ALTER TABLE `products`
  ADD PRIMARY KEY (`product_id`);

--
-- Indexes for table `user_info`
--
ALTER TABLE `user_info`
  ADD PRIMARY KEY (`user_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `admin`
--
ALTER TABLE `admin`
  MODIFY `id` int(100) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `brands`
--
ALTER TABLE `brands`
  MODIFY `brand_id` int(100) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

--
-- AUTO_INCREMENT for table `cart`
--
ALTER TABLE `cart`
  MODIFY `id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `categories`
--
ALTER TABLE `categories`
  MODIFY `cat_id` int(100) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `orders`
--
ALTER TABLE `orders`
  MODIFY `order_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `products`
--
ALTER TABLE `products`
  MODIFY `product_id` int(100) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=99;

--
-- AUTO_INCREMENT for table `user_info`
--
ALTER TABLE `user_info`
  MODIFY `user_id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
